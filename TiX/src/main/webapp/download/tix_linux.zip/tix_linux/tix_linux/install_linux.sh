#!/bin/bash

cd TiX/PythonApp/ClientApp/
sudo python TixApp.py
/etc/TIX/app/startupAppCaller.sh
