#!/bin/bash
pyinstaller Tix/Tix.linux.spec
