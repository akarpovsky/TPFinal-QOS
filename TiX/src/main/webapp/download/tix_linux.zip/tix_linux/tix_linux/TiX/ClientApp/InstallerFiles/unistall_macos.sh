launchctl remove com.user.loginscript
rm ~/Library/LaunchAgents/com.user.loginscript.plist
