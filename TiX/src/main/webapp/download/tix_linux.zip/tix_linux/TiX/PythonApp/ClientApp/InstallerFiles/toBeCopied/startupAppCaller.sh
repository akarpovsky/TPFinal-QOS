#!/bin/bash

sudo python /etc/TIX/app/TixClientApp log
